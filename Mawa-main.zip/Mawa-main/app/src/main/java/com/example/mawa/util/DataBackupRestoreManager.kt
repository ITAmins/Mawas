package com.example.mawa.util

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.net.Uri
import android.widget.Toast
import androidx.core.content.FileProvider
import com.example.mawa.data.local.entity.CashTallyEntity
import com.example.mawa.data.local.entity.CustomerEntity
import com.example.mawa.data.local.entity.DailyCashEntity
import com.example.mawa.data.local.entity.FordiItemEntity
import com.example.mawa.data.local.entity.PersonalTransactionEntity
import com.example.mawa.data.local.entity.PersonalTransactionType
import com.example.mawa.data.local.entity.ProductEntity
import com.example.mawa.data.local.entity.ShopSettingsEntity
import com.example.mawa.data.local.entity.SupplierCompanyEntity
import com.example.mawa.data.local.entity.TransactionEntity
import com.example.mawa.data.local.entity.TransactionType
import com.example.mawa.data.model.CustomerWithBalance
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

data class FullBackupData(
    val exportDate: Long = System.currentTimeMillis(),
    val appVersion: String = "1.0",
    val shopSettings: ShopSettingsEntity? = null,
    val customers: List<CustomerEntity> = emptyList(),
    val transactions: List<TransactionEntity> = emptyList(),
    val fordiItems: List<FordiItemEntity> = emptyList(),
    val products: List<ProductEntity> = emptyList(),
    val personalTransactions: List<PersonalTransactionEntity> = emptyList(),
    val dailyCashRecords: List<DailyCashEntity> = emptyList(),
    val supplierCompanies: List<SupplierCompanyEntity> = emptyList(),
    val cashTallyRecords: List<CashTallyEntity> = emptyList()
)

object DataBackupRestoreManager {

    // ==========================================
    // 1. JSON BACKUP & RESTORE
    // ==========================================

    fun exportToJsonString(data: FullBackupData): String {
        val root = JSONObject()
        root.put("version", "2.0")
        root.put("appName", "MAWA Digital Khata")
        root.put("exportedAt", data.exportDate)
        root.put("exportDateReadable", SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date(data.exportDate)))

        // Shop Settings
        data.shopSettings?.let { s ->
            val sObj = JSONObject()
            sObj.put("id", s.id)
            sObj.put("shopName", s.shopName)
            sObj.put("ownerName", s.ownerName)
            sObj.put("phone", s.phone)
            sObj.put("bkashNumber", s.bkashNumber)
            sObj.put("nagadNumber", s.nagadNumber)
            sObj.put("bankDetails", s.bankDetails)
            sObj.put("qrCodeData", s.qrCodeData)
            sObj.put("openingBalance", s.openingBalance)
            sObj.put("currencySymbol", s.currencySymbol)
            sObj.put("appMode", s.appMode)
            sObj.put("isModeConfigured", s.isModeConfigured)
            sObj.put("createdAt", s.createdAt)
            root.put("shopSettings", sObj)
        }

        // Customers (Standard + BakiModel style baki_records)
        val custArr = JSONArray()
        val bakiRecordsArr = JSONArray()
        data.customers.forEach { c ->
            val obj = JSONObject()
            obj.put("id", c.id)
            obj.put("name", c.name)
            obj.put("customerName", c.name)
            obj.put("phone", c.phone)
            obj.put("address", c.address)
            obj.put("details", c.address)
            obj.put("openingBalance", c.openingBalance)
            obj.put("creditLimit", c.creditLimit)
            obj.put("promisedPaymentDate", c.promisedPaymentDate)
            obj.put("categoryTag", c.categoryTag)
            obj.put("nidOrGuarantor", c.nidOrGuarantor)
            obj.put("note", c.note)
            obj.put("createdAt", c.createdAt)
            obj.put("updatedAt", c.createdAt)
            custArr.put(obj)

            // Also build BakiModel JSON structure for cross-app parity
            val custTxList = data.transactions.filter { it.customerId == c.id || it.customerName.equals(c.name, ignoreCase = true) }
            val totalGiven = custTxList.filter { it.type == TransactionType.SALE_BAKI }.sumOf { it.amount }
            val totalPaid = custTxList.filter { it.type == TransactionType.BAKI_COLLECTION }.sumOf { it.amount }
            val netDue = (c.openingBalance + totalGiven - totalPaid).coerceAtLeast(0.0)

            val bakiObj = JSONObject()
            bakiObj.put("id", c.id.toString())
            bakiObj.put("customerName", c.name)
            bakiObj.put("phone", c.phone)
            bakiObj.put("details", c.address)
            bakiObj.put("amount", netDue)
            bakiObj.put("updatedAt", c.createdAt)

            val innerTxArr = JSONArray()
            custTxList.forEach { ctx ->
                val txO = JSONObject()
                txO.put("id", ctx.id)
                txO.put("type", ctx.type.name)
                txO.put("amount", ctx.amount)
                txO.put("note", ctx.note)
                txO.put("date", SimpleDateFormat("dd-MM-yyyy", Locale.US).format(Date(ctx.timestamp)))
                txO.put("time", SimpleDateFormat("hh:mm a", Locale.US).format(Date(ctx.timestamp)))
                txO.put("updatedAt", ctx.timestamp)
                innerTxArr.put(txO)
            }
            bakiObj.put("transactions", innerTxArr)
            bakiRecordsArr.put(bakiObj)
        }
        root.put("customers", custArr)
        root.put("baki_records", bakiRecordsArr)

        // Transactions
        val txArr = JSONArray()
        data.transactions.forEach { t ->
            val obj = JSONObject()
            obj.put("id", t.id)
            obj.put("type", t.type.name)
            obj.put("banglaType", t.type.banglaLabel)
            obj.put("amount", t.amount)
            obj.put("timestamp", t.timestamp)
            obj.put("customerId", t.customerId ?: -1L)
            obj.put("customerName", t.customerName ?: "")
            obj.put("productId", t.productId ?: -1L)
            obj.put("productName", t.productName ?: "")
            obj.put("quantity", t.quantity)
            obj.put("unit", t.unit)
            obj.put("rate", t.rate)
            obj.put("category", t.category)
            obj.put("note", t.note)
            txArr.put(obj)
        }
        root.put("transactions", txArr)

        // Expenses by Date (for cross-app parity with MawaSyncManager)
        val expensesByDateObj = JSONObject()
        val expensesGrouped = data.transactions.filter {
            it.type == TransactionType.EXPENSE_SHOP ||
            it.type == TransactionType.EXPENSE_HOME ||
            it.type == TransactionType.PURCHASE_DIRECT ||
            it.type == TransactionType.PURCHASE_FORDI ||
            it.type == TransactionType.SALE_CASH
        }.groupBy { SimpleDateFormat("dd-MM-yyyy", Locale.US).format(Date(it.timestamp)) }

        expensesGrouped.forEach { (dateKey, txList) ->
            val expArr = JSONArray()
            txList.forEach { tx ->
                val eo = JSONObject()
                eo.put("id", tx.id.toString())
                eo.put("name", tx.note.ifBlank { tx.category })
                eo.put("amount", tx.amount)
                eo.put("type", tx.type.name)
                eo.put("expenseType", if (tx.type == TransactionType.EXPENSE_HOME) "HOME" else if (tx.type == TransactionType.PURCHASE_DIRECT) "PURCHASE" else "SHOP")
                eo.put("date", dateKey)
                eo.put("time", SimpleDateFormat("hh:mm a", Locale.US).format(Date(tx.timestamp)))
                eo.put("updatedAt", tx.timestamp)
                expArr.put(eo)
            }
            expensesByDateObj.put(dateKey, expArr)
        }
        root.put("expenses_by_date", expensesByDateObj)

        // Fordi Items (Standard + FordiModel style)
        val fordiArr = JSONArray()
        val fordiRecordsArr = JSONArray()
        data.fordiItems.forEach { f ->
            val obj = JSONObject()
            obj.put("id", f.id)
            obj.put("productId", f.productId ?: -1L)
            obj.put("productName", f.productName)
            obj.put("plannedQuantity", f.plannedQuantity)
            obj.put("unit", f.unit)
            obj.put("purchaseRate", f.purchaseRate)
            obj.put("sellingRate", f.sellingRate)
            obj.put("isPurchased", f.isPurchased)
            obj.put("actualQuantity", f.actualQuantity)
            obj.put("actualRate", f.actualRate)
            obj.put("actualTotal", f.actualTotal)
            obj.put("createdAt", f.createdAt)
            obj.put("purchaseDate", f.purchaseDate ?: 0L)
            fordiArr.put(obj)
        }
        root.put("fordiItems", fordiArr)

        // Group fordi items by date for fordi_records
        val fordiByDate = data.fordiItems.groupBy { SimpleDateFormat("dd-MM-yyyy", Locale.US).format(Date(it.createdAt)) }
        fordiByDate.forEach { (fDate, items) ->
            val fGroup = JSONObject()
            fGroup.put("id", "fordi_$fDate")
            fGroup.put("date", fDate)
            fGroup.put("updatedAt", items.firstOrNull()?.createdAt ?: System.currentTimeMillis())
            fGroup.put("postedToAccounting", items.all { it.isPurchased })
            val fItemArr = JSONArray()
            items.forEach { fi ->
                val fo = JSONObject()
                fo.put("productName", fi.productName)
                fo.put("plannedQuantity", fi.plannedQuantity)
                fo.put("unit", fi.unit)
                fo.put("purchaseRate", fi.purchaseRate)
                fo.put("sellingRate", fi.sellingRate)
                fo.put("isChecked", fi.isPurchased)
                fo.put("isPurchased", fi.isPurchased)
                fo.put("actualQuantity", fi.actualQuantity)
                fo.put("actualPurchaseRate", fi.actualRate)
                fo.put("actualTotal", fi.actualTotal)
                fItemArr.put(fo)
            }
            fGroup.put("items", fItemArr)
            fordiRecordsArr.put(fGroup)
        }
        root.put("fordi_records", fordiRecordsArr)

        // Products
        val prodArr = JSONArray()
        data.products.forEach { p ->
            val obj = JSONObject()
            obj.put("id", p.id)
            obj.put("name", p.name)
            obj.put("banglaName", p.banglaName)
            obj.put("unit", p.unit)
            obj.put("defaultPurchasePrice", p.defaultPurchasePrice)
            obj.put("lastPurchasePrice", p.defaultPurchasePrice)
            obj.put("defaultSellingPrice", p.defaultSellingPrice)
            obj.put("sellingPrice", p.defaultSellingPrice)
            obj.put("category", p.category)
            obj.put("createdAt", p.createdAt)
            obj.put("updatedAt", p.createdAt)
            obj.put("isActive", p.isActive)
            prodArr.put(obj)
        }
        root.put("products", prodArr)
        root.put("estimated_gross_margin", 15.0)

        // Personal Transactions
        val ptxArr = JSONArray()
        data.personalTransactions.forEach { pt ->
            val obj = JSONObject()
            obj.put("id", pt.id)
            obj.put("type", pt.type.name)
            obj.put("amount", pt.amount)
            obj.put("title", pt.title)
            obj.put("category", pt.category)
            obj.put("note", pt.note)
            obj.put("timestamp", pt.timestamp)
            ptxArr.put(obj)
        }
        root.put("personalTransactions", ptxArr)

        // Daily Cash Records (both structured array & backward compatible legacy keys)
        val dailyCashArr = JSONArray()
        data.dailyCashRecords.forEach { dc ->
            val obj = JSONObject()
            obj.put("dateKey", dc.dateKey)
            obj.put("dateMillis", dc.dateMillis)
            obj.put("sabekCash", dc.sabekCash)
            obj.put("closingCash", dc.closingCash)
            obj.put("isClosed", dc.isClosed)
            obj.put("updatedAt", dc.updatedAt)
            dailyCashArr.put(obj)

            // Dynamic keys for backward compatibility with old scripts/tools
            if (dc.sabekCash > 0) {
                root.put("key_sabek_cash_${dc.dateKey}", dc.sabekCash)
            }
            if (dc.closingCash > 0) {
                root.put("key_available_cash_${dc.dateKey}", dc.closingCash)
            }
        }
        root.put("dailyCashRecords", dailyCashArr)

        // Supplier Companies
        val compArr = JSONArray()
        data.supplierCompanies.forEach { sc ->
            val obj = JSONObject()
            obj.put("id", sc.id)
            obj.put("companyName", sc.companyName)
            obj.put("srName", sc.srName)
            obj.put("srPhone", sc.srPhone)
            obj.put("orderDay", sc.orderDay)
            obj.put("deliveryDay", sc.deliveryDay)
            obj.put("address", sc.address)
            obj.put("note", sc.note)
            obj.put("createdAt", sc.createdAt)
            compArr.put(obj)
        }
        root.put("supplierCompanies", compArr)

        // Cash Tally Records (Note counting history)
        val tallyArr = JSONArray()
        data.cashTallyRecords.forEach { ct ->
            val obj = JSONObject()
            obj.put("id", ct.id)
            obj.put("dateKey", ct.dateKey)
            obj.put("dateMillis", ct.dateMillis)
            obj.put("count1000", ct.count1000)
            obj.put("count500", ct.count500)
            obj.put("count200", ct.count200)
            obj.put("count100", ct.count100)
            obj.put("count50", ct.count50)
            obj.put("count20", ct.count20)
            obj.put("count10", ct.count10)
            obj.put("count5", ct.count5)
            obj.put("count2", ct.count2)
            obj.put("count1", ct.count1)
            obj.put("totalAmount", ct.totalAmount)
            obj.put("systemBalance", ct.systemBalance)
            obj.put("difference", ct.difference)
            obj.put("note", ct.note)
            obj.put("timestamp", ct.timestamp)
            tallyArr.put(obj)
        }
        root.put("cashTallyRecords", tallyArr)

        return root.toString(2)
    }

    fun parseTransactionType(typeStr: String): TransactionType {
        val clean = typeStr.trim().uppercase(Locale.US).replace(" ", "_").replace("-", "_")
        return when {
            clean == "SALE_CASH" || clean == "CASH_SALE" || clean == "CASH" || clean == "নগদ_বিক্রি" || (clean.contains("নগদ") && clean.contains("বিক্রি")) -> TransactionType.SALE_CASH
            clean == "SALE_BAKI" || clean == "BAKI_SALE" || clean == "CREDIT_SALE" || clean == "BAKI" || clean == "বাকি_বিক্রি" || (clean.contains("বাকি") && clean.contains("বিক্রি")) -> TransactionType.SALE_BAKI
            clean == "BAKI_COLLECTION" || clean == "COLLECTION" || clean == "JOMA" || clean == "BAKI_JOMA" || clean == "বাকি_আদায়" || clean == "বাকি_জমা" || clean.contains("আদায়") || clean.contains("জমা") -> TransactionType.BAKI_COLLECTION
            clean == "PURCHASE_FORDI" || clean == "FORDI_PURCHASE" || clean == "ফর্দ_থেকে_কেনা" || clean.contains("ফর্দ") -> TransactionType.PURCHASE_FORDI
            clean == "PURCHASE_DIRECT" || clean == "PURCHASE" || clean == "BUY" || clean == "সরাসরি_মাল_কেনা" || (clean.contains("মাল") && clean.contains("কেনা")) || clean.contains("ক্রয়") -> TransactionType.PURCHASE_DIRECT
            clean == "EXPENSE_SHOP" || clean == "EXPENSE" || clean == "SHOP_EXPENSE" || clean == "দোকানের_খরচ" || (clean.contains("দোকান") && clean.contains("খরচ")) -> TransactionType.EXPENSE_SHOP
            clean == "EXPENSE_HOME" || clean == "HOME_EXPENSE" || clean == "WITHDRAWAL" || clean == "বাড়ির_খরচ" || clean == "বাড়ির_খরচ/উত্তোলন" || clean.contains("বাড়ি") || clean.contains("উত্তোলন") -> TransactionType.EXPENSE_HOME
            clean == "CASH_ADJUSTMENT" || clean == "ADJUSTMENT" || clean == "নগদ_সমন্বয়" || clean.contains("সমন্বয়") -> TransactionType.CASH_ADJUSTMENT
            else -> {
                try {
                    TransactionType.valueOf(clean)
                } catch (_: Exception) {
                    TransactionType.EXPENSE_SHOP
                }
            }
        }
    }

    fun parsePersonalTransactionType(typeStr: String): PersonalTransactionType {
        val clean = typeStr.trim().uppercase(Locale.US)
        return when {
            clean == "INCOME" || clean == "আয়" || clean.contains("INCOME") || clean.contains("আয়") -> PersonalTransactionType.INCOME
            clean == "EXPENSE" || clean == "খরচ" || clean.contains("EXPENSE") || clean.contains("খরচ") -> PersonalTransactionType.EXPENSE
            clean == "SAVINGS" || clean == "সঞ্চয়" || clean.contains("SAVINGS") || clean.contains("সঞ্চয়") -> PersonalTransactionType.SAVINGS
            else -> {
                try {
                    PersonalTransactionType.valueOf(clean)
                } catch (_: Exception) {
                    PersonalTransactionType.EXPENSE
                }
            }
        }
    }

    fun readTextFromUri(context: Context, uri: Uri): String {
        return context.contentResolver.openInputStream(uri)?.use { inputStream ->
            inputStream.bufferedReader(Charsets.UTF_8).use { reader ->
                reader.readText()
            }
        } ?: throw IllegalArgumentException("ফাইলটি পড়া সম্ভব হয়নি")
    }

    fun parseDateAndTimeToMillis(
        dateStr: String?,
        timeStr: String? = null,
        fallbackMillis: Long = System.currentTimeMillis()
    ): Long {
        if (dateStr.isNullOrBlank()) return fallbackMillis
        val engDate = BengaliUtils.toEnglishDigits(dateStr.trim().replace("/", "-"))
        val engTime = if (!timeStr.isNullOrBlank()) BengaliUtils.toEnglishDigits(timeStr.trim()) else null

        val patternsWithTime = listOf(
            "dd-MM-yyyy hh:mm a",
            "dd-MM-yyyy HH:mm",
            "dd-MM-yyyy hh:mm:ss a",
            "dd-MM-yyyy HH:mm:ss",
            "yyyy-MM-dd HH:mm:ss",
            "yyyy-MM-dd HH:mm",
            "yyyy-MM-dd hh:mm a",
            "yyyy-MM-dd hh:mm:ss a",
            "MM-dd-yyyy hh:mm a",
            "MM-dd-yyyy HH:mm"
        )

        if (!engTime.isNullOrBlank()) {
            val combined = "$engDate $engTime"
            for (pattern in patternsWithTime) {
                try {
                    val sdf = SimpleDateFormat(pattern, Locale.US)
                    sdf.isLenient = true
                    val d = sdf.parse(combined)
                    if (d != null) return d.time
                } catch (_: Exception) {}
            }
        }

        val patternsDateOnly = listOf(
            "dd-MM-yyyy",
            "yyyy-MM-dd",
            "MM-dd-yyyy"
        )
        for (pattern in patternsDateOnly) {
            try {
                val sdf = SimpleDateFormat(pattern, Locale.US)
                sdf.isLenient = true
                val d = sdf.parse(engDate)
                if (d != null) {
                    val cal = Calendar.getInstance()
                    cal.time = d
                    cal.set(Calendar.HOUR_OF_DAY, 12)
                    cal.set(Calendar.MINUTE, 0)
                    cal.set(Calendar.SECOND, 0)
                    cal.set(Calendar.MILLISECOND, 0)
                    return cal.timeInMillis
                }
            } catch (_: Exception) {}
        }

        // Try parsing timestamp if dateStr was numeric millis string
        dateStr.toLongOrNull()?.let {
            if (it > 100000000000L) return it
        }

        return fallbackMillis
    }

    fun isSameDay(t1: Long, t2: Long): Boolean {
        val c1 = Calendar.getInstance().apply { timeInMillis = t1 }
        val c2 = Calendar.getInstance().apply { timeInMillis = t2 }
        return c1.get(Calendar.YEAR) == c2.get(Calendar.YEAR) &&
                c1.get(Calendar.DAY_OF_YEAR) == c2.get(Calendar.DAY_OF_YEAR)
    }

    fun formatDateKey(millis: Long): String {
        return SimpleDateFormat("dd-MM-yyyy", Locale.US).format(Date(millis))
    }

    private fun extractDateStringFromKey(key: String): String {
        // Look for date pattern like DD-MM-YYYY, YYYY-MM-DD, DD/MM/YYYY inside key
        val regex = Regex("""(\d{1,4}[-/]\d{1,2}[-/]\d{1,4})""")
        val match = regex.find(key)
        return if (match != null) {
            match.value.replace("/", "-")
        } else if (key.contains("_")) {
            key.substringAfterLast("_")
        } else {
            ""
        }
    }

    private fun sanitizeJsonText(input: String): String {
        var clean = input.trim()
        if (clean.startsWith("\uFEFF")) {
            clean = clean.substring(1).trim()
        }
        if (clean.startsWith("```json")) {
            clean = clean.removePrefix("```json").trim()
        }
        if (clean.startsWith("```")) {
            clean = clean.removePrefix("```").trim()
        }
        if (clean.endsWith("```")) {
            clean = clean.removeSuffix("```").trim()
        }

        // If it starts with an unexpected character like colon, comma, quote
        if (!clean.startsWith("{") && !clean.startsWith("[")) {
            val firstBrace = clean.indexOf('{')
            val firstBracket = clean.indexOf('[')
            if (firstBrace != -1 && (firstBracket == -1 || firstBrace < firstBracket)) {
                clean = clean.substring(firstBrace)
            } else if (firstBracket != -1) {
                clean = clean.substring(firstBracket)
            } else if (clean.contains("\":") || clean.contains("key_")) {
                // Fragment of JSON object properties
                val firstQuote = clean.indexOf('"')
                if (firstQuote != -1) {
                    clean = "{" + clean.substring(firstQuote)
                } else {
                    clean = "{$clean}"
                }
            }
        }

        // Check matching closing braces
        var openBraceCount = clean.count { it == '{' }
        var closeBraceCount = clean.count { it == '}' }
        while (closeBraceCount < openBraceCount) {
            clean += "}"
            closeBraceCount++
        }

        var openBracketCount = clean.count { it == '[' }
        var closeBracketCount = clean.count { it == ']' }
        while (closeBracketCount < openBracketCount) {
            clean += "]"
            closeBracketCount++
        }

        return clean
    }

    fun parseFromJsonString(jsonString: String): FullBackupData {
        val cleanJson = sanitizeJsonText(jsonString)

        if (cleanJson.startsWith("[")) {
            // Root is an Array of items
            val rootArr = JSONArray(cleanJson)
            val customers = mutableListOf<CustomerEntity>()
            val transactions = mutableListOf<TransactionEntity>()
            val products = mutableListOf<ProductEntity>()
            val fordiItems = mutableListOf<FordiItemEntity>()

            for (i in 0 until rootArr.length()) {
                val item = rootArr.optJSONObject(i) ?: continue
                if (item.has("amount") || item.has("type") || item.has("tx_type") || item.has("taka")) {
                    transactions.add(parseTransactionItem(item))
                } else if (item.has("phone") || item.has("address") || item.has("openingBalance") || item.has("opening_balance") || item.has("baki")) {
                    customers.add(parseCustomerItem(item))
                } else if (item.has("plannedQuantity") || item.has("isPurchased") || item.has("fordi")) {
                    fordiItems.add(parseFordiItem(item))
                } else if (item.has("defaultPurchasePrice") || item.has("defaultSellingPrice") || item.has("banglaName")) {
                    products.add(parseProductItem(item))
                } else if (item.has("name")) {
                    customers.add(parseCustomerItem(item))
                }
            }

            return FullBackupData(
                exportDate = System.currentTimeMillis(),
                customers = customers.distinctBy { it.name.trim().lowercase() },
                transactions = transactions,
                fordiItems = fordiItems,
                products = products.distinctBy { it.name.trim().lowercase() }
            )
        }

        val originalRoot = JSONObject(cleanJson)
        // Unwrap nested payloads if present (e.g. backup_data: { ... }, data: { ... } or backup: { ... })
        val root = when {
            originalRoot.has("backup_data") && originalRoot.optJSONObject("backup_data") != null -> originalRoot.getJSONObject("backup_data")
            originalRoot.has("data") && originalRoot.optJSONObject("data") != null -> originalRoot.getJSONObject("data")
            originalRoot.has("backup") && originalRoot.optJSONObject("backup") != null -> originalRoot.getJSONObject("backup")
            originalRoot.has("payload") && originalRoot.optJSONObject("payload") != null -> originalRoot.getJSONObject("payload")
            else -> originalRoot
        }

        val exportDate = root.optLong("exportedAt", root.optLong("exportDate", System.currentTimeMillis()))

        // Shop Settings
        var settings: ShopSettingsEntity? = null
        val settingsObj = root.optJSONObject("shopSettings") 
            ?: root.optJSONObject("shop_settings") 
            ?: root.optJSONObject("settings") 
            ?: root.optJSONObject("shop")
        if (settingsObj != null) {
            settings = ShopSettingsEntity(
                id = settingsObj.optInt("id", 1),
                shopName = settingsObj.optString("shopName", settingsObj.optString("shop_name", "মাওয়া ডিজিটাল খাতা")),
                ownerName = settingsObj.optString("ownerName", settingsObj.optString("owner_name", "দোকানদার")),
                openingBalance = settingsObj.optDouble("openingBalance", settingsObj.optDouble("opening_balance", 0.0)),
                currencySymbol = settingsObj.optString("currencySymbol", settingsObj.optString("currency_symbol", "৳")),
                phone = settingsObj.optString("phone", settingsObj.optString("mobile", "")),
                bkashNumber = settingsObj.optString("bkashNumber", settingsObj.optString("bkash_number", "")),
                nagadNumber = settingsObj.optString("nagadNumber", settingsObj.optString("nagad_number", "")),
                bankDetails = settingsObj.optString("bankDetails", settingsObj.optString("bank_details", "")),
                qrCodeData = settingsObj.optString("qrCodeData", settingsObj.optString("qr_code_data", "")),
                createdAt = settingsObj.optLong("createdAt", settingsObj.optLong("created_at", System.currentTimeMillis())),
                appMode = settingsObj.optString("appMode", settingsObj.optString("app_mode", "BOTH")),
                isModeConfigured = settingsObj.optBoolean("isModeConfigured", settingsObj.optBoolean("is_mode_configured", true))
            )
        }

        // Customers
        val customers = mutableListOf<CustomerEntity>()
        val custArr = root.optJSONArray("customers") 
            ?: root.optJSONArray("customer_list") 
            ?: root.optJSONArray("customerList") 
            ?: root.optJSONArray("baki_list") 
            ?: root.optJSONArray("clients")
        if (custArr != null) {
            for (i in 0 until custArr.length()) {
                val c = custArr.optJSONObject(i) ?: continue
                customers.add(parseCustomerItem(c))
            }
        }

        // Transactions
        val transactions = mutableListOf<TransactionEntity>()
        val txArr = root.optJSONArray("transactions") 
            ?: root.optJSONArray("transaction_list") 
            ?: root.optJSONArray("transactionList") 
            ?: root.optJSONArray("tx_list") 
            ?: root.optJSONArray("orders") 
            ?: root.optJSONArray("entries")
        if (txArr != null) {
            for (i in 0 until txArr.length()) {
                val t = txArr.optJSONObject(i) ?: continue
                transactions.add(parseTransactionItem(t))
            }
        }

        // Fordi Items
        val fordiItems = mutableListOf<FordiItemEntity>()
        val fordiArr = root.optJSONArray("fordiItems") 
            ?: root.optJSONArray("fordi_items") 
            ?: root.optJSONArray("fordi") 
            ?: root.optJSONArray("shopping_list")
        if (fordiArr != null) {
            for (i in 0 until fordiArr.length()) {
                val f = fordiArr.optJSONObject(i) ?: continue
                fordiItems.add(parseFordiItem(f))
            }
        }

        // Products
        val products = mutableListOf<ProductEntity>()
        val prodArr = root.optJSONArray("products") 
            ?: root.optJSONArray("product_list") 
            ?: root.optJSONArray("productList") 
            ?: root.optJSONArray("items")
        if (prodArr != null) {
            for (i in 0 until prodArr.length()) {
                val p = prodArr.optJSONObject(i) ?: continue
                products.add(parseProductItem(p))
            }
        }

        // Personal Transactions
        val personalTransactions = mutableListOf<PersonalTransactionEntity>()
        val ptxArr = root.optJSONArray("personalTransactions") 
            ?: root.optJSONArray("personal_transactions") 
            ?: root.optJSONArray("personal")
        if (ptxArr != null) {
            for (i in 0 until ptxArr.length()) {
                val pt = ptxArr.optJSONObject(i) ?: continue
                val typeStr = pt.optString("type", pt.optString("tx_type", "EXPENSE"))
                val pType = parsePersonalTransactionType(typeStr)
                personalTransactions.add(
                    PersonalTransactionEntity(
                        id = pt.optLong("id", 0L),
                        type = pType,
                        amount = pt.optDouble("amount", pt.optDouble("taka", 0.0)),
                        title = pt.optString("title", pt.optString("name", "ব্যক্তিগত")),
                        category = pt.optString("category", "অন্যান্য"),
                        note = pt.optString("note", ""),
                        timestamp = pt.optLong("timestamp", pt.optLong("date", System.currentTimeMillis()))
                    )
                )
            }
        }

        // Daily Cash Records (structured)
        val dailyCashMap = mutableMapOf<String, DailyCashEntity>()
        val dailyCashArr = root.optJSONArray("dailyCashRecords") 
            ?: root.optJSONArray("daily_cash_records") 
            ?: root.optJSONArray("daily_cash") 
            ?: root.optJSONArray("dailyCash")
        if (dailyCashArr != null) {
            for (i in 0 until dailyCashArr.length()) {
                val dc = dailyCashArr.optJSONObject(i) ?: continue
                val dKey = dc.optString("dateKey", "")
                val dMillis = dc.optLong("dateMillis", parseDateAndTimeToMillis(dKey))
                val sabek = dc.optDouble("sabekCash", 0.0)
                val closing = dc.optDouble("closingCash", 0.0)
                val closed = dc.optBoolean("isClosed", false)
                val updated = dc.optLong("updatedAt", System.currentTimeMillis())
                if (dKey.isNotBlank()) {
                    dailyCashMap[dKey] = DailyCashEntity(
                        dateKey = dKey,
                        dateMillis = dMillis,
                        sabekCash = sabek,
                        closingCash = closing,
                        isClosed = closed,
                        updatedAt = updated
                    )
                }
            }
        }

        // Check if top-level structured data exists to avoid duplicate parsing from legacy key blocks
        val hasStructuredTransactions = transactions.isNotEmpty()
        val hasStructuredCustomers = customers.isNotEmpty()

        // --- Handle Key-Value / SharedPreferences Backup Format ---
        // e.g. key_baki_records, key_expenses_DD-MM-YYYY, key_fordi_records, key_product_memory, key_sabek_cash_...
        var latestSabekCashDate = 0L
        var latestSabekCashValue = 0.0

        val keys = root.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            val lowerKey = key.lowercase()

            // 1. Customer Baki records (e.g. key_baki_records, baki_list, etc.)
            // Only parse if top-level structured arrays were missing in the backup file
            if (!hasStructuredCustomers && (lowerKey.contains("baki_record") || lowerKey.contains("baki_list") || lowerKey == "key_baki_records" || lowerKey == "baki")) {
                val bakiArr = root.optJSONArray(key)
                if (bakiArr != null) {
                    for (i in 0 until bakiArr.length()) {
                        val cObj = bakiArr.optJSONObject(i) ?: continue
                        if (cObj.optLong("deletedAt", 0L) > 0) continue
                        val custName = cObj.optString("customerName", cObj.optString("name", "নামহীন")).trim()
                        if (custName.isBlank()) continue
                        val phone = cObj.optString("phone", cObj.optString("mobile", "")).trim()
                        val address = cObj.optString("details", cObj.optString("address", "")).trim()
                        val totalAmt = cObj.optDouble("amount", cObj.optDouble("baki", cObj.optDouble("due", 0.0)))
                        val txArrInner = cObj.optJSONArray("transactions")

                        var hasSpecificTransactions = false
                        if (!hasStructuredTransactions && txArrInner != null && txArrInner.length() > 0) {
                            for (j in 0 until txArrInner.length()) {
                                val txObj = txArrInner.optJSONObject(j) ?: continue
                                if (txObj.optLong("deletedAt", 0L) > 0) continue
                                val txAmt = txObj.optDouble("amount", txObj.optDouble("taka", 0.0))
                                if (txAmt <= 0) continue
                                hasSpecificTransactions = true
                                val typeStr = txObj.optString("type", txObj.optString("tx_type", "BAKI")).uppercase()
                                val txType = if (typeStr.contains("JOMA") || typeStr.contains("COLLECTION") || typeStr.contains("PAYMENT") || typeStr.contains("RECEIVED") || typeStr.contains("জমা") || typeStr.contains("আদায়")) {
                                    TransactionType.BAKI_COLLECTION
                                } else {
                                    TransactionType.SALE_BAKI
                                }
                                val note = txObj.optString("note", txObj.optString("memo", if (txType == TransactionType.SALE_BAKI) "বাকি বিক্রি" else "বাকি আদায়"))
                                val dateStr = txObj.optString("date", "")
                                val timeStr = txObj.optString("time", "")
                                val updatedAt = txObj.optLong("updatedAt", txObj.optLong("timestamp", 0L))
                                val ts = if (dateStr.isNotBlank()) {
                                    parseDateAndTimeToMillis(dateStr, timeStr, if (updatedAt > 0) updatedAt else System.currentTimeMillis())
                                } else {
                                    if (updatedAt > 0) updatedAt else System.currentTimeMillis()
                                }
                                transactions.add(
                                    TransactionEntity(
                                        type = txType,
                                        amount = txAmt,
                                        customerName = custName,
                                        note = note,
                                        category = "বাকি",
                                        timestamp = ts
                                    )
                                )
                            }
                        }

                        customers.add(
                            CustomerEntity(
                                name = custName,
                                phone = phone,
                                address = address,
                                openingBalance = if (!hasSpecificTransactions) totalAmt else 0.0
                            )
                        )
                    }
                }
            }

            // 2. Expenses / Purchases / Sales by date (e.g. expenses_by_date, key_expenses_06-08-2026, expenses_..., etc.)
            // Only parse if top-level structured transactions array was absent
            if (!hasStructuredTransactions && (lowerKey.contains("expense") || lowerKey.contains("cost_") || lowerKey.contains("khoroch"))) {
                val expArr = root.optJSONArray(key)
                val expObj = root.optJSONObject(key)
                val dateFromKey = extractDateStringFromKey(key)

                val listToProcess = mutableListOf<Pair<String, JSONObject>>()
                if (expArr != null) {
                    for (i in 0 until expArr.length()) {
                        val item = expArr.optJSONObject(i) ?: continue
                        listToProcess.add(dateFromKey to item)
                    }
                } else if (expObj != null) {
                    val dKeys = expObj.keys()
                    while (dKeys.hasNext()) {
                        val dKey = dKeys.next()
                        val subArr = expObj.optJSONArray(dKey)
                        if (subArr != null) {
                            for (j in 0 until subArr.length()) {
                                val item = subArr.optJSONObject(j) ?: continue
                                listToProcess.add(dKey to item)
                            }
                        }
                    }
                }

                for ((dKey, item) in listToProcess) {
                    if (item.optLong("deletedAt", 0L) > 0) continue
                    val amt = item.optDouble("amount", item.optDouble("taka", item.optDouble("cost", 0.0)))
                    if (amt <= 0) continue
                    val name = item.optString("name", item.optString("title", item.optString("note", "খরচ"))).trim()
                    val typeStr = item.optString("type", "").uppercase()
                    val expType = item.optString("expenseType", item.optString("expense_type", item.optString("category", ""))).uppercase()
                    val dateStr = item.optString("date", dKey)
                    val timeStr = item.optString("time", "")
                    val updatedAt = item.optLong("updatedAt", item.optLong("timestamp", item.optLong("createdAt", 0L)))
                    val ts = if (dateStr.isNotBlank()) {
                        parseDateAndTimeToMillis(dateStr, timeStr, if (updatedAt > 0) updatedAt else System.currentTimeMillis())
                    } else {
                        if (updatedAt > 0) updatedAt else System.currentTimeMillis()
                    }

                    val txType = when {
                        typeStr == "SALE_CASH" || typeStr == "SALE" || typeStr == "CASH" || typeStr == "INCOME" || expType == "SALE" || expType == "INCOME" || name.contains("নগদ বিক্রি") || name.contains("মোট বিক্রি") || name.contains("বেচা") -> TransactionType.SALE_CASH
                        typeStr == "SALE_BAKI" || typeStr == "BAKI" || expType == "BAKI" || name.contains("বাকি বিক্রি") -> TransactionType.SALE_BAKI
                        typeStr == "BAKI_COLLECTION" || typeStr == "COLLECTION" || typeStr == "JOMA" || expType == "COLLECTION" || name.contains("বাকি আদায়") || name.contains("জমা") -> TransactionType.BAKI_COLLECTION
                        typeStr == "PURCHASE" || expType == "PURCHASE" || name.contains("মাল কেনা") || name.contains("ক্রয়") -> TransactionType.PURCHASE_DIRECT
                        typeStr == "HOME" || expType == "HOME" || name.contains("সংসার") || name.contains("উত্তোলন") || name.contains("বাড়ি") -> TransactionType.EXPENSE_HOME
                        else -> TransactionType.EXPENSE_SHOP
                    }

                    transactions.add(
                        TransactionEntity(
                            type = txType,
                            amount = amt,
                            productName = if (txType == TransactionType.PURCHASE_DIRECT) name else null,
                            note = name,
                            category = if (txType == TransactionType.EXPENSE_HOME) "সংসার" else if (txType == TransactionType.PURCHASE_DIRECT) "পণ্য ক্রয়" else if (txType == TransactionType.SALE_CASH) "বিক্রি" else "দোকান খরচ",
                            timestamp = ts
                        )
                    )
                }
            }

            // 3. Fordi / Shopping list (e.g. key_fordi_records, fordis, etc.)
            if (lowerKey.contains("fordi_records") || lowerKey.contains("fordi_list") || lowerKey == "key_fordi_records" || lowerKey == "fordi") {
                val fordiGroupArr = root.optJSONArray(key)
                if (fordiGroupArr != null) {
                    for (i in 0 until fordiGroupArr.length()) {
                        val gObj = fordiGroupArr.optJSONObject(i) ?: continue
                        if (gObj.optLong("deletedAt", 0L) > 0) continue
                        val itemsArr = gObj.optJSONArray("items")
                        val groupDate = gObj.optString("date", "")
                        val groupUpdatedAt = gObj.optLong("updatedAt", gObj.optLong("createdAt", parseDateAndTimeToMillis(groupDate)))
                        val isPosted = gObj.optBoolean("postedToAccounting", false)

                        if (itemsArr != null && itemsArr.length() > 0) {
                            for (j in 0 until itemsArr.length()) {
                                val item = itemsArr.optJSONObject(j) ?: continue
                                val pName = item.optString("productName", item.optString("name", "পণ্য")).trim()
                                if (pName.isBlank()) continue
                                val pQty = item.optDouble("plannedQuantity", item.optDouble("quantity", 1.0))
                                val unit = item.optString("unit", "কেজি")
                                val pRate = item.optDouble("purchaseRate", item.optDouble("actualPurchaseRate", 0.0))
                                val sRate = item.optDouble("sellingRate", 0.0)
                                val isChecked = item.optBoolean("isChecked", false)
                                val status = item.optString("status", "")
                                val isPurchased = isChecked || status == "FULLY_BOUGHT" || isPosted
                                val actQty = item.optDouble("actualQuantity", 0.0)
                                val actRate = item.optDouble("actualPurchaseRate", item.optDouble("actualRate", 0.0))
                                val actTotal = item.optDouble("actualTotal", 0.0)

                                fordiItems.add(
                                    FordiItemEntity(
                                        productName = pName,
                                        plannedQuantity = if (pQty > 0) pQty else 1.0,
                                        unit = unit,
                                        purchaseRate = pRate,
                                        sellingRate = sRate,
                                        isPurchased = isPurchased,
                                        actualQuantity = actQty,
                                        actualRate = actRate,
                                        actualTotal = actTotal,
                                        createdAt = groupUpdatedAt,
                                        purchaseDate = if (isPurchased) groupUpdatedAt else null
                                    )
                                )
                            }
                        } else {
                            fordiItems.add(parseFordiItem(gObj))
                        }
                    }
                }
            }

            // 4. Products / Product Memory (e.g. key_product_memory)
            if (lowerKey.contains("product_memory") || lowerKey == "key_product_memory") {
                val prodArrInner = root.optJSONArray(key)
                if (prodArrInner != null) {
                    for (i in 0 until prodArrInner.length()) {
                        val p = prodArrInner.optJSONObject(i) ?: continue
                        if (p.optLong("deletedAt", 0L) > 0) continue
                        val name = p.optString("name", p.optString("product_name", "")).trim()
                        if (name.isBlank()) continue
                        val category = p.optString("category", "মুদি").trim()
                        val unit = p.optString("unit", "কেজি").trim()
                        val pPrice = p.optDouble("lastPurchasePrice", p.optDouble("averagePurchasePrice", p.optDouble("defaultPurchasePrice", 0.0)))
                        val sPrice = p.optDouble("sellingPrice", p.optDouble("defaultSellingPrice", 0.0))
                        val createdAt = p.optLong("createdAt", p.optLong("updatedAt", System.currentTimeMillis()))
                        products.add(
                            ProductEntity(
                                name = name,
                                banglaName = name,
                                category = category,
                                unit = unit,
                                defaultPurchasePrice = pPrice,
                                defaultSellingPrice = sPrice,
                                createdAt = createdAt
                            )
                        )
                    }
                }
            }

            // 5. Product Suggestions (e.g. key_product_suggestions)
            if (lowerKey.contains("product_suggestions") || lowerKey == "key_product_suggestions") {
                val suggArr = root.optJSONArray(key)
                if (suggArr != null) {
                    for (i in 0 until suggArr.length()) {
                        val sName = suggArr.optString(i, "").trim()
                        if (sName.isNotBlank()) {
                            products.add(
                                ProductEntity(
                                    name = sName,
                                    banglaName = sName,
                                    category = "মুদি",
                                    unit = "কেজি"
                                )
                            )
                        }
                    }
                }
            }

            // 6. Cash Sales by date (e.g. key_cash_sale_15-06-2026, cash_sale_...)
            // Only parse if top-level structured transactions array was absent
            if (!hasStructuredTransactions && (lowerKey.contains("cash_sale") || lowerKey.contains("nogod_sale") || lowerKey.contains("daily_sale"))) {
                val saleAmt = root.optDouble(key, 0.0)
                if (saleAmt > 0) {
                    val dateStr = extractDateStringFromKey(key)
                    val ts = parseDateAndTimeToMillis(dateStr)
                    transactions.add(
                        TransactionEntity(
                            type = TransactionType.SALE_CASH,
                            amount = saleAmt,
                            note = if (dateStr.isNotBlank()) "নগদ বিক্রি ($dateStr)" else "নগদ বিক্রি",
                            timestamp = ts
                        )
                    )
                }
            }

            // 7. Sabek Cash by date (e.g. key_sabek_cash_29-08-2026, sabek_cash_...)
            if (lowerKey.contains("sabek_cash") || lowerKey.contains("opening_cash") || lowerKey.contains("starting_cash") || lowerKey == "openingbalance" || lowerKey == "opening_balance") {
                val sabekAmt = root.optDouble(key, 0.0)
                val dateStr = extractDateStringFromKey(key)
                val ts = if (dateStr.isNotBlank()) parseDateAndTimeToMillis(dateStr) else 0L
                if (sabekAmt > 0) {
                    if (ts >= latestSabekCashDate || latestSabekCashValue == 0.0) {
                        latestSabekCashDate = ts
                        latestSabekCashValue = sabekAmt
                    }
                    if (dateStr.isNotBlank()) {
                        val existing = dailyCashMap[dateStr]
                        dailyCashMap[dateStr] = existing?.copy(sabekCash = sabekAmt)
                            ?: DailyCashEntity(dateKey = dateStr, dateMillis = ts, sabekCash = sabekAmt)
                    }
                }
            }

            // 8. Available / Closing Cash by date (e.g. key_available_cash_29-08-2026, key_closing_cash_..., key_available_cash)
            if (lowerKey.contains("available_cash") || lowerKey.contains("closing_cash") || lowerKey.contains("hatekash") || lowerKey.contains("hate_cash")) {
                val closingAmt = root.optDouble(key, 0.0)
                val dateStr = extractDateStringFromKey(key)
                val ts = if (dateStr.isNotBlank()) parseDateAndTimeToMillis(dateStr) else 0L
                if (closingAmt > 0) {
                    if (dateStr.isNotBlank()) {
                        val existing = dailyCashMap[dateStr]
                        dailyCashMap[dateStr] = existing?.copy(closingCash = closingAmt)
                            ?: DailyCashEntity(dateKey = dateStr, dateMillis = ts, closingCash = closingAmt)
                    } else if (lowerKey == "key_available_cash") {
                        if (latestSabekCashValue == 0.0) latestSabekCashValue = closingAmt
                    }
                }
            }
        }

        // Apply latest opening balance if available
        if (latestSabekCashValue > 0) {
            settings = (settings ?: ShopSettingsEntity()).copy(openingBalance = latestSabekCashValue)
        }

        // Auto-reconcile cash sales for dates where closing cash and expenses exist, but no explicit sale was exported
        // Only run if top-level structured transactions array was absent
        if (!hasStructuredTransactions) {
            dailyCashMap.forEach { (dateKey, dailyCash) ->
                if (dailyCash.closingCash > 0) {
                    val dayExpenses = transactions.filter {
                        isSameDay(it.timestamp, dailyCash.dateMillis) &&
                                (it.type == TransactionType.EXPENSE_SHOP ||
                                 it.type == TransactionType.EXPENSE_HOME ||
                                 it.type == TransactionType.PURCHASE_DIRECT ||
                                 it.type == TransactionType.PURCHASE_FORDI)
                    }.sumOf { it.amount }

                    val hasExplicitSale = transactions.any {
                        isSameDay(it.timestamp, dailyCash.dateMillis) && it.type == TransactionType.SALE_CASH
                    }

                    if (!hasExplicitSale && dayExpenses > 0) {
                        val computedSale = (dailyCash.closingCash + dayExpenses - dailyCash.sabekCash).coerceAtLeast(0.0)
                        if (computedSale > 0) {
                            transactions.add(
                                TransactionEntity(
                                    type = TransactionType.SALE_CASH,
                                    amount = computedSale,
                                    note = "নগদ বিক্রি ($dateKey)",
                                    timestamp = dailyCash.dateMillis
                                )
                            )
                        }
                    }
                }
            }
        }

        // Deduplicate parsed transactions to prevent duplicate entries across varying formats
        val distinctTransactions = transactions.distinctBy {
            val cName = it.customerName?.trim()?.lowercase() ?: ""
            val pName = it.productName?.trim()?.lowercase() ?: ""
            val amtCents = (it.amount * 100).toLong()
            val type = it.type.name
            val note = it.note.trim().lowercase()
            val timeWindow = it.timestamp / 30000L
            "${type}_${amtCents}_${cName}_${pName}_${note}_${timeWindow}"
        }

        // Supplier Companies
        val supplierCompanies = mutableListOf<SupplierCompanyEntity>()
        val compArr = root.optJSONArray("supplierCompanies") ?: root.optJSONArray("companies")
        if (compArr != null) {
            for (i in 0 until compArr.length()) {
                val sc = compArr.optJSONObject(i) ?: continue
                val name = sc.optString("companyName", sc.optString("name", "")).trim()
                if (name.isNotBlank()) {
                    supplierCompanies.add(
                        SupplierCompanyEntity(
                            id = sc.optLong("id", 0L),
                            companyName = name,
                            srName = sc.optString("srName", sc.optString("sr_name", "")),
                            srPhone = sc.optString("srPhone", sc.optString("sr_phone", "")),
                            orderDay = sc.optString("orderDay", sc.optString("order_day", "")),
                            deliveryDay = sc.optString("deliveryDay", sc.optString("delivery_day", "")),
                            address = sc.optString("address", ""),
                            note = sc.optString("note", ""),
                            createdAt = sc.optLong("createdAt", System.currentTimeMillis())
                        )
                    )
                }
            }
        }

        // Cash Tally Records
        val cashTallyRecords = mutableListOf<CashTallyEntity>()
        val tallyArr = root.optJSONArray("cashTallyRecords") ?: root.optJSONArray("cashTallies")
        if (tallyArr != null) {
            for (i in 0 until tallyArr.length()) {
                val ct = tallyArr.optJSONObject(i) ?: continue
                cashTallyRecords.add(
                    CashTallyEntity(
                        id = ct.optLong("id", 0L),
                        dateKey = ct.optString("dateKey", ""),
                        dateMillis = ct.optLong("dateMillis", System.currentTimeMillis()),
                        count1000 = ct.optInt("count1000", 0),
                        count500 = ct.optInt("count500", 0),
                        count200 = ct.optInt("count200", 0),
                        count100 = ct.optInt("count100", 0),
                        count50 = ct.optInt("count50", 0),
                        count20 = ct.optInt("count20", 0),
                        count10 = ct.optInt("count10", 0),
                        count5 = ct.optInt("count5", 0),
                        count2 = ct.optInt("count2", 0),
                        count1 = ct.optInt("count1", 0),
                        totalAmount = ct.optDouble("totalAmount", 0.0),
                        systemBalance = ct.optDouble("systemBalance", 0.0),
                        difference = ct.optDouble("difference", 0.0),
                        note = ct.optString("note", ""),
                        timestamp = ct.optLong("timestamp", System.currentTimeMillis())
                    )
                )
            }
        }

        return FullBackupData(
            exportDate = exportDate,
            shopSettings = settings,
            customers = customers.distinctBy { it.name.trim().lowercase() },
            transactions = distinctTransactions,
            fordiItems = fordiItems,
            products = products.distinctBy { it.name.trim().lowercase() },
            personalTransactions = personalTransactions,
            dailyCashRecords = dailyCashMap.values.toList(),
            supplierCompanies = supplierCompanies.distinctBy { it.companyName.trim().lowercase() },
            cashTallyRecords = cashTallyRecords
        )
    }

    private fun parseCustomerItem(c: JSONObject): CustomerEntity {
        return CustomerEntity(
            id = c.optLong("id", 0L),
            name = c.optString("name", c.optString("customer_name", c.optString("customerName", "নামহীন"))),
            phone = c.optString("phone", c.optString("mobile", c.optString("contact", ""))),
            address = c.optString("address", c.optString("location", "")),
            openingBalance = c.optDouble("openingBalance", c.optDouble("opening_balance", c.optDouble("baki", c.optDouble("due", 0.0)))),
            creditLimit = c.optDouble("creditLimit", c.optDouble("credit_limit", 0.0)),
            promisedPaymentDate = c.optLong("promisedPaymentDate", c.optLong("promised_payment_date", 0L)),
            categoryTag = c.optString("categoryTag", c.optString("category_tag", "REGULAR")),
            nidOrGuarantor = c.optString("nidOrGuarantor", c.optString("nid_or_guarantor", "")),
            note = c.optString("note", c.optString("remark", "")),
            createdAt = c.optLong("createdAt", c.optLong("created_at", System.currentTimeMillis()))
        )
    }

    private fun parseTransactionItem(t: JSONObject): TransactionEntity {
        val typeStr = t.optString("type", t.optString("tx_type", t.optString("transaction_type", "EXPENSE_SHOP")))
        val txType = parseTransactionType(typeStr)
        val custId = t.optLong("customerId", t.optLong("customer_id", -1L))
        val prodId = t.optLong("productId", t.optLong("product_id", -1L))

        val dateStr = t.optString("date", "")
        val timeStr = t.optString("time", "")
        val tsRaw = t.optLong("timestamp", t.optLong("created_at", t.optLong("updatedAt", 0L)))
        val ts = if (tsRaw > 0) {
            tsRaw
        } else if (dateStr.isNotBlank() && dateStr.contains(Regex("[0-9]"))) {
            parseDateAndTimeToMillis(dateStr, timeStr, System.currentTimeMillis())
        } else {
            t.optLong("date", System.currentTimeMillis())
        }

        return TransactionEntity(
            id = t.optLong("id", 0L),
            type = txType,
            amount = t.optDouble("amount", t.optDouble("taka", t.optDouble("total", 0.0))),
            timestamp = ts,
            customerId = if (custId > 0) custId else null,
            customerName = t.optString("customerName", t.optString("customer_name", "")).takeIf { it.isNotBlank() },
            productId = if (prodId > 0) prodId else null,
            productName = t.optString("productName", t.optString("product_name", "")).takeIf { it.isNotBlank() },
            quantity = t.optDouble("quantity", t.optDouble("qty", 0.0)),
            unit = t.optString("unit", "টি"),
            rate = t.optDouble("rate", t.optDouble("price", 0.0)),
            category = t.optString("category", "সাধারণ"),
            note = t.optString("note", t.optString("memo", "")),
            paymentStatus = t.optString("paymentStatus", t.optString("payment_status", "PAID")),
            promisedPaymentDate = t.optLong("promisedPaymentDate", t.optLong("promised_payment_date", 0L))
        )
    }

    private fun parseFordiItem(f: JSONObject): FordiItemEntity {
        val prodId = f.optLong("productId", f.optLong("product_id", -1L))
        return FordiItemEntity(
            id = f.optLong("id", 0L),
            productId = if (prodId > 0) prodId else null,
            productName = f.optString("productName", f.optString("product_name", f.optString("name", "পণ্য"))),
            plannedQuantity = f.optDouble("plannedQuantity", f.optDouble("planned_quantity", f.optDouble("quantity", 1.0))),
            unit = f.optString("unit", "কেজি"),
            purchaseRate = f.optDouble("purchaseRate", f.optDouble("purchase_rate", f.optDouble("rate", 0.0))),
            sellingRate = f.optDouble("sellingRate", f.optDouble("selling_rate", 0.0)),
            isPurchased = f.optBoolean("isPurchased", f.optBoolean("is_purchased", false)),
            actualQuantity = f.optDouble("actualQuantity", f.optDouble("actual_quantity", 0.0)),
            actualRate = f.optDouble("actualRate", f.optDouble("actual_rate", 0.0)),
            actualTotal = f.optDouble("actualTotal", f.optDouble("actual_total", 0.0)),
            companyName = f.optString("companyName", f.optString("company_name", "")),
            orderDay = f.optString("orderDay", f.optString("order_day", "")),
            deliveryDay = f.optString("deliveryDay", f.optString("delivery_day", "")),
            createdAt = f.optLong("createdAt", f.optLong("created_at", System.currentTimeMillis())),
            purchaseDate = f.optLong("purchaseDate", f.optLong("purchase_date", 0L)).takeIf { it > 0 }
        )
    }

    private fun parseProductItem(p: JSONObject): ProductEntity {
        return ProductEntity(
            id = p.optLong("id", 0L),
            name = p.optString("name", p.optString("product_name", "পণ্য")),
            banglaName = p.optString("banglaName", p.optString("bangla_name", "")),
            unit = p.optString("unit", "কেজি"),
            defaultPurchasePrice = p.optDouble("defaultPurchasePrice", p.optDouble("default_purchase_price", p.optDouble("purchase_price", 0.0))),
            defaultSellingPrice = p.optDouble("defaultSellingPrice", p.optDouble("default_selling_price", p.optDouble("selling_price", 0.0))),
            category = p.optString("category", "মুদি"),
            createdAt = p.optLong("createdAt", p.optLong("created_at", System.currentTimeMillis())),
            isActive = p.optBoolean("isActive", p.optBoolean("is_active", true))
        )
    }

    // ==========================================
    // 2. CSV EXPORT & IMPORT
    // ==========================================

    fun generateCustomersCsv(customers: List<CustomerWithBalance>): String {
        val sb = StringBuilder()
        sb.append("আইডি,কাস্টমার নাম,মোবাইল,ঠিকানা,পূর্বের বাকি (৳),মোট বাকি দেওয়া (৳),মোট জমা পাওয়া (৳),বর্তমান বাকি ব্যালেন্স (৳)\n")
        for (c in customers) {
            val name = c.customer.name.replace(",", " ")
            val phone = c.customer.phone.replace(",", " ")
            val address = c.customer.address.replace(",", " ")
            sb.append("${c.customer.id},\"$name\",\"$phone\",\"$address\",${c.customer.openingBalance},${c.totalBakiGiven},${c.totalJomaReceived},${c.currentBalance}\n")
        }
        return sb.toString()
    }

    fun generateFordiCsv(fordiItems: List<FordiItemEntity>): String {
        val sb = StringBuilder()
        sb.append("আইডি,পণ্যের নাম,পরিমাণ,একক,ক্রয় দর (৳),বিক্রয় দর (৳),কেনা হয়েছে কি,প্রকৃত মোট টাকা (৳)\n")
        for (f in fordiItems) {
            val name = f.productName.replace(",", " ")
            sb.append("${f.id},\"$name\",${f.plannedQuantity},\"${f.unit}\",${f.purchaseRate},${f.sellingRate},${if (f.isPurchased) "হ্যাঁ" else "না"},${f.actualTotal}\n")
        }
        return sb.toString()
    }

    fun parseCustomersFromCsv(csvText: String): List<CustomerEntity> {
        val list = mutableListOf<CustomerEntity>()
        val lines = csvText.lines()
        for (line in lines) {
            val trimmed = line.trim()
            if (trimmed.isBlank() || trimmed.startsWith("আইডি") || trimmed.startsWith("ID") || trimmed.startsWith("Name") || trimmed.startsWith("নাম")) continue
            val parts = trimmed.split(",(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)".toRegex())
            if (parts.isNotEmpty()) {
                val name = (if (parts.size > 1) parts[1] else parts[0]).replace("\"", "").trim()
                val phone = (if (parts.size > 2) parts[2] else "").replace("\"", "").trim()
                val address = (if (parts.size > 3) parts[3] else "").replace("\"", "").trim()
                val opening = (if (parts.size > 4) parts[4] else "").replace("\"", "").trim().toDoubleOrNull() ?: 0.0
                if (name.isNotBlank()) {
                    list.add(
                        CustomerEntity(
                            name = name,
                            phone = phone,
                            address = address,
                            openingBalance = opening
                        )
                    )
                }
            }
        }
        return list
    }

    // ==========================================
    // 3. MODERN BRANDED MEMO IMAGE GENERATION (PNG)
    // ==========================================

    fun createCustomerBakiMemoBitmap(
        shopName: String,
        shopPhone: String,
        customerWithBalance: CustomerWithBalance,
        recentTransactions: List<TransactionEntity>
    ): Bitmap {
        val width = 900
        val height = 1200
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        // Background
        val bgPaint = Paint().apply { color = Color.parseColor("#F8F9FD") }
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)

        // Card Container
        val cardPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
        val cardRect = RectF(40f, 40f, width - 40f, height - 40f)
        canvas.drawRoundRect(cardRect, 30f, 30f, cardPaint)

        // Top Banner Header
        val headerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#1B5E20") }
        val headerRect = RectF(40f, 40f, width - 40f, 220f)
        canvas.drawRoundRect(headerRect, 30f, 30f, headerPaint)
        canvas.drawRect(40f, 190f, width - 40f, 220f, headerPaint)

        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 44f
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText(shopName.ifBlank { "মাওয়া স্মার্ট খাতা" }, width / 2f, 110f, titlePaint)

        val subtitlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#E8F5E9")
            textSize = 24f
            textAlign = Paint.Align.CENTER
        }
        val dateStr = SimpleDateFormat("dd MMMM yyyy, hh:mm a", Locale.getDefault()).format(Date())
        canvas.drawText("কাস্টমার বাকি খতিয়ান ও হিসাব বিবরণী · $dateStr", width / 2f, 160f, subtitlePaint)
        if (shopPhone.isNotBlank()) {
            canvas.drawText("যোগাযোগ: $shopPhone", width / 2f, 195f, subtitlePaint)
        }

        // Customer Info Card
        val custInfoBg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#F1F5F9") }
        val custRect = RectF(70f, 250f, width - 70f, 390f)
        canvas.drawRoundRect(custRect, 20f, 20f, custInfoBg)

        val textDark = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#0F172A")
            textSize = 30f
            isFakeBoldText = true
        }
        val textMuted = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#64748B")
            textSize = 24f
        }

        val cust = customerWithBalance.customer
        canvas.drawText("গ্রাহকের নাম: ${cust.name}", 95f, 298f, textDark)
        val phoneStr = if (cust.phone.isNotBlank()) "মোবাইল: ${cust.phone}" else "মোবাইল: প্রযোজ্য নয়"
        val addrStr = if (cust.address.isNotBlank()) "ঠিকানা: ${cust.address}" else ""
        canvas.drawText("$phoneStr  ${if (addrStr.isNotBlank()) " · $addrStr" else ""}", 95f, 342f, textMuted)

        // Balance Highlight Badge
        val isDue = customerWithBalance.currentBalance > 0
        val badgeColor = if (isDue) Color.parseColor("#DC2626") else Color.parseColor("#16A34A")
        val balanceBoxPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = badgeColor }
        val balRect = RectF(70f, 415f, width - 70f, 545f)
        canvas.drawRoundRect(balRect, 24f, 24f, balanceBoxPaint)

        val balLabelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 24f
            textAlign = Paint.Align.CENTER
        }
        val balValPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 52f
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText(if (isDue) "বর্তমান মোট বকেয়া বাকি" else "বর্তমান মোট জমা ব্যালেন্স", width / 2f, 460f, balLabelPaint)
        canvas.drawText(BengaliUtils.formatTaka(customerWithBalance.currentBalance), width / 2f, 520f, balValPaint)

        // Table Header
        var currentY = 590f
        val tableHeaderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#E2E8F0") }
        canvas.drawRoundRect(RectF(70f, currentY, width - 70f, currentY + 50f), 10f, 10f, tableHeaderPaint)

        val thText = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#334155")
            textSize = 22f
            isFakeBoldText = true
        }
        canvas.drawText("তারিখ ও বিবরণ", 90f, currentY + 34f, thText)
        canvas.drawText("বাকি (+)", width - 340f, currentY + 34f, thText)
        canvas.drawText("জমা (−)", width - 180f, currentY + 34f, thText)

        currentY += 75f

        // Previous Balance Row
        if (cust.openingBalance > 0) {
            canvas.drawText("সাবেক / পূর্বের জের", 90f, currentY, textDark)
            canvas.drawText(BengaliUtils.formatTaka(cust.openingBalance), width - 340f, currentY, textDark)
            canvas.drawText("-", width - 160f, currentY, textMuted)
            currentY += 45f
            val linePaint = Paint().apply { color = Color.parseColor("#E2E8F0"); strokeWidth = 1.5f }
            canvas.drawLine(70f, currentY - 15f, width - 70f, currentY - 15f, linePaint)
        }

        // List Transactions
        val dateFormat = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault())
        val displayTx = recentTransactions.take(8)
        for (tx in displayTx) {
            val timeStr = dateFormat.format(Date(tx.timestamp))
            val noteStr = if (tx.note.isNotBlank()) " (${tx.note})" else ""
            val desc = "${if (tx.type == TransactionType.SALE_BAKI) "বাকি খরিদ" else "নগদ জমা"}$noteStr"

            val itemPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#1E293B"); textSize = 22f }
            val itemSub = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#64748B"); textSize = 18f }

            canvas.drawText(desc, 90f, currentY, itemPaint)
            canvas.drawText(timeStr, 90f, currentY + 24f, itemSub)

            if (tx.type == TransactionType.SALE_BAKI) {
                val redAmt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#DC2626"); textSize = 24f; isFakeBoldText = true }
                canvas.drawText(BengaliUtils.formatTaka(tx.amount), width - 340f, currentY + 10f, redAmt)
                canvas.drawText("-", width - 160f, currentY + 10f, textMuted)
            } else {
                val greenAmt = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#16A34A"); textSize = 24f; isFakeBoldText = true }
                canvas.drawText("-", width - 320f, currentY + 10f, textMuted)
                canvas.drawText(BengaliUtils.formatTaka(tx.amount), width - 200f, currentY + 10f, greenAmt)
            }

            currentY += 60f
            val linePaint = Paint().apply { color = Color.parseColor("#F1F5F9"); strokeWidth = 1.5f }
            canvas.drawLine(70f, currentY - 10f, width - 70f, currentY - 10f, linePaint)
        }

        // Summary Totals Card
        val sumBoxPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#F8FAFC") }
        val sumRect = RectF(70f, height - 230f, width - 70f, height - 100f)
        canvas.drawRoundRect(sumRect, 16f, 16f, sumBoxPaint)

        val sumBorder = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#CBD5E1")
            style = Paint.Style.STROKE
            strokeWidth = 2f
        }
        canvas.drawRoundRect(sumRect, 16f, 16f, sumBorder)

        val sumValRed = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#DC2626"); textSize = 24f; isFakeBoldText = true }
        val sumValGreen = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#16A34A"); textSize = 24f; isFakeBoldText = true }

        canvas.drawText("মোট বাকি: ${BengaliUtils.formatTaka(customerWithBalance.totalBakiGiven + cust.openingBalance)}", 95f, height - 170f, sumValRed)
        canvas.drawText("মোট পরিশোধিত: ${BengaliUtils.formatTaka(customerWithBalance.totalJomaReceived)}", width - 420f, height - 170f, sumValGreen)

        // Footer Branding Watermark
        val footerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#94A3B8")
            textSize = 20f
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("MAWA ডিজিটাল ক্যাশ ও খতিয়ান দ্বারা স্বয়ংক্রিয়ভাবে প্রস্তুতকৃত মেমো", width / 2f, height - 60f, footerPaint)

        return bitmap
    }

    fun createDailyCashboxMemoBitmap(
        shopName: String,
        dateLabel: String,
        openingCash: Double,
        cashSales: Double,
        bakiCollection: Double,
        ownerDeposit: Double,
        purchases: Double,
        expenses: Double,
        ownerWithdrawal: Double,
        closingBalance: Double
    ): Bitmap {
        val width = 900
        val height = 1250
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        // Background
        val bgPaint = Paint().apply { color = Color.parseColor("#F4F6FB") }
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)

        // Card Container
        val cardPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
        val cardRect = RectF(40f, 40f, width - 40f, height - 40f)
        canvas.drawRoundRect(cardRect, 30f, 30f, cardPaint)

        // Header Banner (Navy/Blue theme for Cashbox)
        val headerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#0F172A") }
        val headerRect = RectF(40f, 40f, width - 40f, 220f)
        canvas.drawRoundRect(headerRect, 30f, 30f, headerPaint)
        canvas.drawRect(40f, 190f, width - 40f, 220f, headerPaint)

        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 42f
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText(shopName.ifBlank { "মাওয়া স্মার্ট খাতা" }, width / 2f, 110f, titlePaint)

        val subtitlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#94A3B8")
            textSize = 24f
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("দৈনিক ক্যাশবক্স হিসাব ও মিলানোর রসিদ · $dateLabel", width / 2f, 165f, subtitlePaint)

        // 2 Column Header: পেলাম (Green) vs দিলাম (Red)
        val currentY = 260f
        val colWidth = (width - 160f) / 2f

        // Left Inflow Box (পেলাম)
        val inBg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#ECFDF5") }
        canvas.drawRoundRect(RectF(70f, currentY, 70f + colWidth, currentY + 540f), 16f, 16f, inBg)

        val inHeader = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#065F46")
            textSize = 26f
            isFakeBoldText = true
        }
        canvas.drawText("★ ক্যাশ আগমন (পেলাম)", 90f, currentY + 45f, inHeader)

        val textRegular = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#1F2937"); textSize = 22f }
        val textGreen = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#059669"); textSize = 22f; isFakeBoldText = true }

        var inY = currentY + 100f
        canvas.drawText("দিনের শুরুতে ক্যাশ:", 90f, inY, textRegular)
        canvas.drawText(BengaliUtils.formatTaka(openingCash), 90f, inY + 30f, textGreen)

        inY += 80f
        canvas.drawText("নগদ বেচা:", 90f, inY, textRegular)
        canvas.drawText(BengaliUtils.formatTaka(cashSales), 90f, inY + 30f, textGreen)

        inY += 80f
        canvas.drawText("বাকি আদায়:", 90f, inY, textRegular)
        canvas.drawText(BengaliUtils.formatTaka(bakiCollection), 90f, inY + 30f, textGreen)

        inY += 80f
        canvas.drawText("মালিক দিল (জমা):", 90f, inY, textRegular)
        canvas.drawText(BengaliUtils.formatTaka(ownerDeposit), 90f, inY + 30f, textGreen)

        val totalIn = openingCash + cashSales + bakiCollection + ownerDeposit
        inY += 80f
        val linePaintGreen = Paint().apply { color = Color.parseColor("#A7F3D0"); strokeWidth = 2f }
        canvas.drawLine(90f, inY, 70f + colWidth - 20f, inY, linePaintGreen)
        inY += 35f
        canvas.drawText("মোট আগমন: ${BengaliUtils.formatTaka(totalIn)}", 90f, inY, inHeader)

        // Right Outflow Box (দিলাম)
        val outX = 90f + colWidth
        val outBg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#FEF2F2") }
        canvas.drawRoundRect(RectF(outX, currentY, outX + colWidth, currentY + 540f), 16f, 16f, outBg)

        val outHeader = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#991B1B")
            textSize = 26f
            isFakeBoldText = true
        }
        canvas.drawText("★ ক্যাশ প্রদান (দিলাম)", outX + 20f, currentY + 45f, outHeader)

        val textRed = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#DC2626"); textSize = 22f; isFakeBoldText = true }

        var outY = currentY + 100f
        canvas.drawText("ক্যাশ মাল কেনা:", outX + 20f, outY, textRegular)
        canvas.drawText(BengaliUtils.formatTaka(purchases), outX + 20f, outY + 30f, textRed)

        outY += 80f
        canvas.drawText("দোকানের খরচ:", outX + 20f, outY, textRegular)
        canvas.drawText(BengaliUtils.formatTaka(expenses), outX + 20f, outY + 30f, textRed)

        outY += 80f
        canvas.drawText("মালিক নিল (সংসার):", outX + 20f, outY, textRegular)
        canvas.drawText(BengaliUtils.formatTaka(ownerWithdrawal), outX + 20f, outY + 30f, textRed)

        val totalOut = purchases + expenses + ownerWithdrawal
        outY += 160f
        val linePaintRed = Paint().apply { color = Color.parseColor("#FECACA"); strokeWidth = 2f }
        canvas.drawLine(outX + 20f, outY, outX + colWidth - 20f, outY, linePaintRed)
        outY += 35f
        canvas.drawText("মোট প্রদান: ${BengaliUtils.formatTaka(totalOut)}", outX + 20f, outY, outHeader)

        // Closing Balance Grand Card
        val closeY = currentY + 570f
        val closeBg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#1E3A8A") }
        canvas.drawRoundRect(RectF(70f, closeY, width - 70f, closeY + 160f), 24f, 24f, closeBg)

        val closeLabel = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#93C5FD")
            textSize = 26f
            textAlign = Paint.Align.CENTER
        }
        val closeVal = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 58f
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("দিনের শেষ ক্যাশবক্স ব্যালেন্স (ক্যাশ ইন হ্যান্ড)", width / 2f, closeY + 55f, closeLabel)
        canvas.drawText(BengaliUtils.formatTaka(closingBalance), width / 2f, closeY + 125f, closeVal)

        // Footer Branding
        val footerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#94A3B8")
            textSize = 20f
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("MAWA ডিজিটাল ক্যাশ ও খতিয়ান · বিশ্বস্ত আধুনিক হিসাব ব্যবস্থা", width / 2f, height - 60f, footerPaint)

        return bitmap
    }

    fun createMonthlyReportMemoBitmap(
        shopName: String,
        periodLabel: String,
        totalSales: Double,
        purchases: Double,
        shopExpenses: Double,
        netProfit: Double,
        homeWithdrawals: Double,
        profitRemaining: Double
    ): Bitmap {
        val width = 900
        val height = 1200
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        // Background
        val bgPaint = Paint().apply { color = Color.parseColor("#F8F9FD") }
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)

        // Card Container
        val cardPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
        val cardRect = RectF(40f, 40f, width - 40f, height - 40f)
        canvas.drawRoundRect(cardRect, 30f, 30f, cardPaint)

        // Header Banner
        val headerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#1E1B4B") }
        val headerRect = RectF(40f, 40f, width - 40f, 220f)
        canvas.drawRoundRect(headerRect, 30f, 30f, headerPaint)
        canvas.drawRect(40f, 190f, width - 40f, 220f, headerPaint)

        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 44f
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText(shopName.ifBlank { "মাওয়া স্মার্ট খাতা" }, width / 2f, 110f, titlePaint)

        val subtitlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#C7D2FE")
            textSize = 24f
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("লাভ-ক্ষতি ও ব্যবসা কর্মক্ষমতা স্টেটমেন্ট · $periodLabel", width / 2f, 165f, subtitlePaint)

        // Net Profit Highlight Card
        val profitBg = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = if (netProfit >= 0) Color.parseColor("#16A34A") else Color.parseColor("#DC2626")
        }
        val profitRect = RectF(70f, 250f, width - 70f, 390f)
        canvas.drawRoundRect(profitRect, 24f, 24f, profitBg)

        val pLabelPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = 24f; textAlign = Paint.Align.CENTER }
        val pValPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textSize = 54f; isFakeBoldText = true; textAlign = Paint.Align.CENTER }
        canvas.drawText("ব্যবসায়িক নিট লাভ", width / 2f, 295f, pLabelPaint)
        canvas.drawText(BengaliUtils.formatTaka(netProfit), width / 2f, 355f, pValPaint)

        // Detailed Table Rows
        var currentY = 430f
        val textDark = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#0F172A"); textSize = 26f }
        val textVal = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#0F172A"); textSize = 26f; isFakeBoldText = true; textAlign = Paint.Align.RIGHT }
        val linePaint = Paint().apply { color = Color.parseColor("#E2E8F0"); strokeWidth = 1.5f }

        fun drawRow(label: String, amount: Double, colorHex: String, prefix: String = "") {
            canvas.drawText(label, 80f, currentY + 30f, textDark)
            val valPaint = Paint(textVal).apply { color = Color.parseColor(colorHex) }
            canvas.drawText("$prefix${BengaliUtils.formatTaka(amount)}", width - 80f, currentY + 30f, valPaint)
            currentY += 60f
            canvas.drawLine(80f, currentY, width - 80f, currentY, linePaint)
            currentY += 20f
        }

        drawRow("মোট বিক্রি (নগদ + বাকি)", totalSales, "#0F172A")
        drawRow("মোট মাল কেনা (ফর্দ + ডিলার)", purchases, "#DC2626", "−")
        drawRow("দোকানের পরিচালনা খরচ", shopExpenses, "#DC2626", "−")
        drawRow("বাড়ির জন্য নেওয়া (সংসার উত্তোলন)", homeWithdrawals, "#D97706", "−")

        // Final Retained Profit Box
        val remBg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#F1F5F9") }
        val remRect = RectF(70f, currentY + 10f, width - 70f, currentY + 130f)
        canvas.drawRoundRect(remRect, 20f, 20f, remBg)

        val remLabel = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#475569"); textSize = 24f }
        val remVal = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#1B5E20"); textSize = 34f; isFakeBoldText = true; textAlign = Paint.Align.RIGHT }
        canvas.drawText("বাড়ির খরচ বাদ দিয়ে অবশিষ্ট নিট মুনাফা:", 90f, currentY + 75f, remLabel)
        canvas.drawText(BengaliUtils.formatTaka(profitRemaining), width - 90f, currentY + 75f, remVal)

        // Footer Branding
        val footerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#94A3B8")
            textSize = 20f
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("MAWA ডিজিটাল খাতা ও হিসাব রিপোর্ট · নিরাপদ ও স্বয়ংক্রিয় ব্যাকআপ সমর্থিত", width / 2f, height - 60f, footerPaint)

        return bitmap
    }

    fun createFordiMemoBitmap(
        shopName: String,
        dateLabel: String,
        fordiItems: List<FordiItemEntity>
    ): Bitmap {
        return createFordiMemoBitmap(shopName = shopName, items = fordiItems, dateLabel = dateLabel)
    }

    fun createFordiMemoBitmap(
        shopName: String,
        items: List<FordiItemEntity>,
        dateLabel: String = BengaliUtils.formatDateForExport(System.currentTimeMillis())
    ): Bitmap {
        val fordiItems = items
        val width = 900
        val height = 1200
        val bitmap = Bitmap.createBitmap(width, height, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)

        // Background
        val bgPaint = Paint().apply { color = Color.parseColor("#F8F9FD") }
        canvas.drawRect(0f, 0f, width.toFloat(), height.toFloat(), bgPaint)

        // Card Container
        val cardPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE }
        val cardRect = RectF(40f, 40f, width - 40f, height - 40f)
        canvas.drawRoundRect(cardRect, 30f, 30f, cardPaint)

        // Header Banner
        val headerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#047857") }
        val headerRect = RectF(40f, 40f, width - 40f, 200f)
        canvas.drawRoundRect(headerRect, 30f, 30f, headerPaint)
        canvas.drawRect(40f, 170f, width - 40f, 200f, headerPaint)

        val titlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.WHITE
            textSize = 44f
            isFakeBoldText = true
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText(shopName.ifBlank { "মাওয়া স্মার্ট খাতা" }, width / 2f, 100f, titlePaint)

        val subtitlePaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#A7F3D0")
            textSize = 24f
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("দোকানের বাজার ফর্দ ও মহাজন ক্রয় তালিকা · $dateLabel", width / 2f, 150f, subtitlePaint)

        // Table Header
        var currentY = 240f
        val tableHeaderPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#E2E8F0") }
        canvas.drawRoundRect(RectF(70f, currentY, width - 70f, currentY + 50f), 10f, 10f, tableHeaderPaint)

        val thText = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#334155"); textSize = 22f; isFakeBoldText = true }
        canvas.drawText("নং", 90f, currentY + 34f, thText)
        canvas.drawText("পণ্যের নাম", 150f, currentY + 34f, thText)
        canvas.drawText("পরিমাণ", width - 380f, currentY + 34f, thText)
        canvas.drawText("দর", width - 260f, currentY + 34f, thText)
        canvas.drawText("মোট (৳)", width - 150f, currentY + 34f, thText)

        currentY += 75f
        var totalAmount = 0.0

        for ((index, item) in fordiItems.take(12).withIndex()) {
            val itemTotal = if (item.isPurchased) item.actualTotal else (item.plannedQuantity * item.purchaseRate)
            totalAmount += itemTotal

            val textItem = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#1E293B"); textSize = 22f }
            val numStr = BengaliUtils.toBengaliDigits((index + 1).toString())
            canvas.drawText(numStr, 90f, currentY, textItem)
            canvas.drawText(item.productName, 150f, currentY, textItem)
            canvas.drawText("${BengaliUtils.formatNumber(item.plannedQuantity)} ${item.unit}", width - 380f, currentY, textItem)
            canvas.drawText(BengaliUtils.formatNumber(item.purchaseRate), width - 260f, currentY, textItem)

            val amtPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#047857"); textSize = 22f; isFakeBoldText = true }
            canvas.drawText(BengaliUtils.formatNumber(itemTotal), width - 150f, currentY, amtPaint)

            currentY += 50f
            val linePaint = Paint().apply { color = Color.parseColor("#F1F5F9"); strokeWidth = 1.5f }
            canvas.drawLine(70f, currentY - 15f, width - 70f, currentY - 15f, linePaint)
        }

        // Total Footer Card
        val sumBoxPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#ECFDF5") }
        val sumRect = RectF(70f, height - 200f, width - 70f, height - 100f)
        canvas.drawRoundRect(sumRect, 16f, 16f, sumBoxPaint)

        val sumText = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#065F46"); textSize = 26f; isFakeBoldText = true }
        canvas.drawText("ফর্দের সর্বমোট সম্ভাব্য কেনা খরচ:", 95f, height - 145f, sumText)
        val sumVal = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.parseColor("#047857"); textSize = 36f; isFakeBoldText = true; textAlign = Paint.Align.RIGHT }
        canvas.drawText(BengaliUtils.formatTaka(totalAmount), width - 95f, height - 145f, sumVal)

        // Footer Branding
        val footerPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
            color = Color.parseColor("#94A3B8")
            textSize = 20f
            textAlign = Paint.Align.CENTER
        }
        canvas.drawText("MAWA ডিজিটাল খাতা · ফর্দ তালিকা প্রিন্ট ও শেয়ার রসিদ", width / 2f, height - 50f, footerPaint)

        return bitmap
    }

    // ==========================================
    // 4. FILE SHARING & IMAGE SAVING ENGINE
    // ==========================================

    fun shareBitmapAsImage(context: Context, bitmap: Bitmap, fileNamePrefix: String, title: String) {
        try {
            val cacheDir = File(context.cacheDir, "images")
            if (!cacheDir.exists()) cacheDir.mkdirs()

            val file = File(cacheDir, "${fileNamePrefix}_${System.currentTimeMillis()}.png")
            val out = FileOutputStream(file)
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
            out.flush()
            out.close()

            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)

            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "image/png"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, title)
                putExtra(Intent.EXTRA_TEXT, title)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }

            val chooser = Intent.createChooser(intent, title)
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(chooser)
        } catch (e: Exception) {
            Toast.makeText(context, "ছবি শেয়ার করতে সমস্যা হয়েছে: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
        }
    }

    fun writeTextToUri(context: Context, uri: Uri, content: String): Boolean {
        return try {
            context.contentResolver.openOutputStream(uri)?.use { outputStream ->
                outputStream.write(content.toByteArray(Charsets.UTF_8))
                outputStream.flush()
            }
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }

    fun shareTextFile(context: Context, content: String, fileName: String, mimeType: String, title: String) {
        try {
            val cacheDir = File(context.cacheDir, "reports")
            if (!cacheDir.exists()) cacheDir.mkdirs()

            val file = File(cacheDir, fileName)
            file.writeText(content)

            val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)

            val intent = Intent(Intent.ACTION_SEND).apply {
                type = mimeType
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, title)
                putExtra(Intent.EXTRA_TEXT, content)
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }

            val chooser = Intent.createChooser(intent, title)
            chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(chooser)
        } catch (e: Exception) {
            Toast.makeText(context, "ফাইল শেয়ার ব্যর্থ হয়েছে: ${e.localizedMessage}", Toast.LENGTH_LONG).show()
        }
    }

    // ==========================================
    // 5. WHATSAPP & SMS QUICK REMINDER
    // ==========================================

    fun generateBengaliPaymentReminderText(
        shopName: String,
        customerName: String,
        balance: Double,
        shopPhone: String
    ): String {
        return """
শ্রদ্ধেয় $customerName ভাই,
$shopName-এ আপনার বকেয়া বাকি মোট: ${BengaliUtils.formatTaka(balance)}।

হিসাবের স্বচ্ছতা বজায় রাখতে অনুগ্রহ করে আপনার সুবিধাজনক সময়ে বকেয়া টাকা পরিশোধের ব্যবস্থা করবেন।
${if (shopPhone.isNotBlank()) "যেকোনো তথ্যে যোগাযোগ: $shopPhone" else ""}

ধন্যবাদান্তে,
$shopName
        """.trimIndent()
    }

    fun sendWhatsAppMessage(context: Context, phone: String, message: String) {
        try {
            val cleanPhone = phone.replace("[^0-9+]".toRegex(), "")
            val finalPhone = when {
                cleanPhone.startsWith("+88") -> cleanPhone.substring(1)
                cleanPhone.startsWith("01") -> "88$cleanPhone"
                else -> cleanPhone
            }

            val uri = Uri.parse("https://api.whatsapp.com/send?phone=$finalPhone&text=${Uri.encode(message)}")
            val intent = Intent(Intent.ACTION_VIEW, uri)
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            context.startActivity(intent)
        } catch (e: Exception) {
            shareText(context, message, "বাকি তাগাদা বার্তা")
        }
    }

    fun shareText(context: Context, text: String, title: String) {
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_SUBJECT, title)
            putExtra(Intent.EXTRA_TEXT, text)
        }
        val chooser = Intent.createChooser(intent, title)
        chooser.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(chooser)
    }
}
